#include <iostream>

using std::cout;
using std::endl;

class Classe1 {
public:

    virtual void VIRTUAL() // fun��o virtual
    {
        cout << "Classe1\n";
    }

    void NAO_VIRTUAL() // fun��o comum
    {
        cout << "Classe1\n";
    }
};

class Classe2 : public Classe1 {
public:

    virtual void VIRTUAL() // sobrescrita
    {
        cout << "Classe2\n";
    }

    void NAO_VIRTUAL() // comum sobrescrita
    {
        cout << "Classe2\n";
    }
};

int main ()
{
    Classe1 *ptr_c1;
    Classe2 derivada;

    ptr_c1 = &derivada;           // convers�o impl�cita permiss�vel
    ptr_c1->VIRTUAL();       // chamada polim�rfica (mostra: "Classe2")
    ptr_c1->NAO_VIRTUAL();   // chamada comum, n�o-polim�rfica (mostra: "Classe1")

    return 0;
}
