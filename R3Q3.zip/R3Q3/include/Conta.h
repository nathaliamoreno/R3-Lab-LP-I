#ifndef CONTA_H
#define CONTA_H
#include "IConta.h"
#include <string>
#include "Conta.h"

class Conta : public IConta
{
    public:
        Conta(std::string nome, double salario, double nCont, double sald);
        void sacar(double valor);
        void depositar(double valor);

        void setNome(std::string nome);
        void setSalario(double salario);
        void setnumConta(std::string nCont);
        void setSaldo(double sald);
        void setLimite (double lim);

        std::string getNome();
        double getSalario();
        std::string getNumConta();
        double getSaldo();
        double getLimite();

        void definirLimite();



    protected:
        std::string nomeCliente;
        double salarioMensal;
        std::string numeroConta;
        double saldo;
        double limite;


    private:
};

#endif // CONTA_H
