#include <iostream>
#include "IConta.h"
#include "Conta.h"
#include "ContaEspecial.h"

using namespace std;

int main()
{

    Conta c1 = Conta();
    ContaEspecial c2 = ContaEspecial();

    cout << "\n\t<<<<< TESTANDO VALORES >>>>\n";

    c1.sacar(5000);

   cout << "\n Saldo da Conta apos saque: R$ " << c1.getSaldo() << endl;

   c1.depositar(2000);

   cout << " Saldo da Conta apos deposito: R$ " << c1.getSaldo() << endl;

   c1.definirLimite();

   cout << " Limite da Conta: R$ " << c1.getLimite() << endl << endl;


   c2.sacar(1500);

   cout << " Saldo da Conta Especial apos saque: R$ " << c2.getSaldo() << endl;

   c2.depositar(1000);

   cout << " Saldo da Conta Especial apos deposito: R$ " << c2.getSaldo() << endl;

   c2.definirLimite();

   cout << " Limite da Conta Especial: R$ " << c2.getLimite() << endl;


    return 0;
}
