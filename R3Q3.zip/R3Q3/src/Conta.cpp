#include "Conta.h"

Conta::Conta(std::string nome, double salario, double nCont, double sald)
{
    nomeCliente = nome;
    salarioMensal = salario;
    numeroConta = nCont;
    saldo = sald;
}
void Conta::sacar(double valor){

}
void Conta::depositar(double valor){

}
void Conta::setNome(std::string nome){
    nomeCliente = nome;
}
void Conta::setSalario(double salario){
    salarioMensal = salario;
}
void Conta::setnumConta(std::string nCont){
    numeroConta = nCont;
}
void Conta::setSaldo(double sald){
    saldo = sald;
}
void Conta::setLimite (double lim){
        limite = lim;
}
std::string Conta::getNome(){
    return nomeCliente;
}
double Conta::getSalario(){
    return salarioMensal;
}
std::string Conta::getNumConta(){
    return numeroConta;
}
double Conta::getSaldo(){
    return saldo;
}
double Conta::getLimite(){
    return limite;
}
void Conta::definirLimite(){
    double sal;

    limite = salarioMensal*2;

}
