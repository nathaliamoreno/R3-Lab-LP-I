#include "IConta.h"

IConta::IConta()
{
    //ctor
}

IConta::~IConta()
{
    //dtor
}
void IConta::sacar(double valor){

}

void IConta::depositar(double valor){

}
