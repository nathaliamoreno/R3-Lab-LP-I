#include "IConta.h"

IConta::IConta()
{
}
void IConta::sacar(double valor)
{
}
void IConta::depositar(double valor)
{
}
