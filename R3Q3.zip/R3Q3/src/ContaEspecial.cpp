#include "ContaEspecial.h"

ContaEspecial::ContaEspecial()
{

}
ContaEspecial::definirLimite()
{
    limite = salarioMensal*3;
}
