#include <iostream>
#include "FiguraGeometrica.h"
#include "Triangulo.h"
#include "Retangulo.h"
#include "Circulo.h"

using namespace std;

int main()
{
    FiguraGeometrica *fig[3];
    fig[0] = new Retangulo(2, 5);
    fig[1] = new Circulo(2);
    fig[2] = new Triangulo(2, 5);

    for (int i = 0; i < 3; i++){

        cout << "Area: " << fig[i]->calcularArea() << endl;
    }

    return 0;
}
