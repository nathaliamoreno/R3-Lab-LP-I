#ifndef FIGURAGEOMETRICA_H
#define FIGURAGEOMETRICA_H


class FiguraGeometrica
{
    public:
        FiguraGeometrica();
        virtual double calcularArea()=0;

    protected:

    private:
};

#endif // FIGURAGEOMETRICA_H
