#ifndef RETANGULO_H
#define RETANGULO_H
#include "FiguraGeometrica.h"

class Retangulo : public FiguraGeometrica
{
    public:
        Retangulo(double b, double h);
        double calcularArea();
    protected:

    private:
        double base;
        double altura;
};

#endif // RETANGULO_H
