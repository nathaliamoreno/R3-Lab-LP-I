#include "Circulo.h"

Circulo::Circulo(double r)
{
    raio = r;
}

double Circulo::calcularArea()
{
    double areaCir = 0;

    areaCir = 3,14*(raio*raio);
    return areaCir;
}
