#include "Triangulo.h"

Triangulo::Triangulo(double b, double h)
{
     base = b;
     altura = h;
}

double Triangulo::calcularArea()
{
    double areaTri = 0;

    areaTri = (base*altura)/2;
    return areaTri;
}
