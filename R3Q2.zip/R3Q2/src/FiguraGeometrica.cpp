#include "FiguraGeometrica.h"

FiguraGeometrica::FiguraGeometrica()
{
}
double  FiguraGeometrica::calcularArea()
{
}
