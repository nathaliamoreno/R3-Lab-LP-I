#include "Retangulo.h"

Retangulo::Retangulo(double b, double h)
{
    base = b;
    altura = h;
}
double Retangulo::calcularArea(){

    double areaRet = 0;

    areaRet = base*altura;

return areaRet;
}
