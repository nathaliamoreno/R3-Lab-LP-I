#include <iostream>
#include "Conta.h"
#include "ContaCorrente.h"
#include "ContaEspecial.h"
#include "Poupanca.h"

using namespace std;

int main()
{
    Poupanca p1 = Poupanca();
    ContaCorrente c1 = ContaCorrente();
    ContaEspecial e1 = ContaEspecial();


    cout << "\n<<<< Poupan�a >>>>\n";
    cout << "\n Nome: " << p1.getNomeCliente() << endl;
    cout << " Numero: " << p1.getNumero() << endl;
    cout <<" Saldo: R$ " << p1.getSaldo() << endl;
    cout <<" Taxa de rendimento: " << p1.getTaxaRendimento() << endl;
    cout << " Variacao: " << p1.getVariacao() << endl;
    cout<< " Saldo: R$ " << p1.getSaldo() << endl;

    cout << "\n\n<<<< Conta Corrente >>>>\n" << "\n Nome: "  << c1.getNomeCliente() << endl ;
    cout <<" Numero: " << c1.getNumero() << endl;
    cout<< " Saldo: R$ " << c1.getSaldo() << endl;
    cout << " Limite: R$ " << c1.definirLimite() << endl;


    cout << "\n\n<<<< Conta Especial >>>>\n" << "\n Nome: "  << e1.getNomeCliente() << endl;
    cout << " Numero: " << e1.getNumero() << endl;
    cout << " Saldo: R$ " << e1.getSaldo() << endl;
    cout << " Limite: R$ " << e1.definirLimite() << endl;


    return 0;
}
