#include "ContaEspecial.h"

ContaEspecial::ContaEspecial() : ContaCorrente(1000, 2000)
{

}

ContaEspecial::~ContaEspecial()
{

}

double ContaEspecial::definirLimite()
{
    limite = 4 * salario;
    return limite;
}
