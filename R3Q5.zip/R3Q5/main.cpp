#include <iostream>
#include "Funcionario.h"
#include "Horista.h"
#include "Assalariado.h"
#include "SistemaGerenciaFolha.h"
#include "Comissionado.h"

using namespace std;

#define salarioBase 1000.0

int main()
{
    cout << "\n\t**** SISTEMA DE GERENCIAMENTO DE FOLHA ****" << endl;

    SistemaGerenciaFolha f;
    Funcionario *func;

    cout << "\n\n SALARIO BASE PARA TODOS: R$ 1000\n\n" << endl;

    cout << "\n\n<<<< testando assalariado >>>>\n";

    func = new Assalariado();
    func->setNome("MARIA");
    func->setMatricula(123);
    f.setFuncionarios(func);

    cout << "\n Nome: " << func->getNome() << endl;
    cout << "\n Matricula: " << func->getMatricula() << endl;
    cout << "\n Salario: R$ " << func->calcularSalario(salarioBase)<< endl;;

    cout << "\n\n<<<< testando comissionado >>>>\n";

    func = new Comissionado(2000, 10);   //passando vendas semanais e percentual da comissao;
    func->setNome("NATHALIA");
    func->setMatricula(456);
    f.setFuncionarios(func);

    cout << "\n Nome: " << func->getNome() << endl;
    cout << "\n Matricula: " << func->getMatricula() << endl;
    cout << "\n Comissao definida em 10% em cima de R$ 2000\n\n Salario: R$ " << func->calcularSalario(salarioBase)<<endl;

    cout << "\n\n<<<< testando horista >>>>\n";

    func = new Horista(45); //passando horas totais trabalhadas na semana
    func->setNome("DERZU");
    func->setMatricula(789);
    f.setFuncionarios(func);

    cout << "\n Nome: " << func->getNome() << endl;
    cout << "\n Matricula: " << func->getMatricula() << endl;
    cout << "\n Horas trabalhadas definidas como 45h \n\n Salario: R$ " << func->calcularSalario(salarioBase)<< endl;;


    cout << "\n\n<<<< testando calcula valor total da folha >>>>\n";
    cout << "\n Total da folha de pagamento: R$ "<< f.calculaValorTotalFolha()<< endl;

    cout << "\n\n<<<< testando consulta valor de salario do funcionario >>>>\n";
    f.consultaSalarioFuncionario();
    cout << "\nO salario desse funcionario eh : " << func->calcularSalario(salarioBase) << std::endl;

    return 0;
}
